import MoneyDisplay from "../ui/MoneyDisplay";

export default class MoneySystem {

    constructor(scene, initialMoney, refundRate) {
        
        this.scene = scene;

        this.money = initialMoney;

        this.refundRate = refundRate;

        this.moneyDisplay = new MoneyDisplay(
            this,
            20,
            40,
            this.money
        );
    }

    spentMoney(amount) {
        this.money -= amount;

        this.moneyDisplay.update(this.money);
    }

    gainMoney(amount) {
        this.money += amount;

        this.moneyDisplay.update(this.money);
    }
}