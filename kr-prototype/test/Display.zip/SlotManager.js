import Slot from '../entities/Slot';
import Tower from '../entities/Tower';
import { towerTypes } from '../data/towers';
// import { slots } from '../data/levels';

export default class SlotManager {

    constructor(scene, slots) {

        this.scene = scene;
        this.slots = slots;
        // this.moneySystem = this.scene.moneySystem;

        this.slots.forEach(slot => {
            slot = new Slot(
                this.scene,
                slot.x,
                slot.y,
                slot.initialCost,
            )

            slot.setInteractive();
            slot.on('pointerdown', () => {
                this.buildTower(slot);
            });
        })
    }

    buildTower(slot) {

        const towerType = towerTypes.basic;

        if (this.scene.money < towerType.cost) {
            return;
        }

        this.scene.moneySystem.spentMoney(towerType.cost);

        this.updateMoneyDisplay();
        this.scene.mone

        const tower = new Tower(
            this.scene,
            slot.x,
            slot.y,
            towerType,
            this
        );

        this.towers.push(tower);

        slot.setVisible(false);
        slot.disableInteractive();

        tower.buildSlot = slot;

        tower.setInteractive();

        tower.on('pointerdown', () => {
            this.sellTower(tower);
        });
    }
}