export default class LifeSystem {

    constructor(scene, initialLives) {

        this.scene = scene;

        this.lives = initialLives;
    }

    lose(amount) {

        this.lives -= amount;

        if (this.lives <= 0) {

            this.lives = 0;

            this.scene.scene.start('GameOver');
        }

        this.scene.livesDisplay.update(
            this.scene.lifeSystem.update(this.lives)
        );
    }
}