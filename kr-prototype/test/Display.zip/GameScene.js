import * as Phaser from 'phaser';

import WaveManager from '../systems/WaveManager';
import TowerManager from '../systems/TowerManager';
import SlotManager from '../systems/SlotManager';
import LifeSystem from '../systems/LifeSystem';
import MoneySystem from '../systems/MoneySystem';

import LivesDisplay from '../ui/LivesDisplay';
import MoneyDisplay from '../ui/MoneyDisplay';

import { waves } from '../data/waves';
import { slots } from '../data/levels';
import { runState } from '../state/RunState';

export default class GameScene extends Phaser.Scene {

    constructor() {
        super('GameScene');
    }

    create() {

        this.cameras.main.setBackgroundColor('#222222');

        this.add.text(
            this.scale.width / 2,
            50,
            'FASE 1',
            {
                fontSize: '32px',
                color: '#ffffff'
            }
        ).setOrigin(0.5);


        // =========================
        // CAMINHO DOS INIMIGOS
        // =========================

        const waypoints = [

            {
                x: -30,
                y: this.scale.height / 2
            },

            {
                x: this.scale.width / 2 - 100,
                y: this.scale.height / 2
            },

            {
                x: this.scale.width / 2,
                y: this.scale.height / 2 + 100
            },

            {
                x: this.scale.width + 30,
                y: this.scale.height / 2 + 100
            }

        ];

        this.path = new Phaser.Curves.Path(
            waypoints[0].x,
            waypoints[0].y
        );

        waypoints.slice(1).forEach(point => {

            this.path.lineTo(
                point.x,
                point.y
            );

        });


        // =========================
        // VISUAL DO CAMINHO
        // =========================

        const visualPath = this.add.graphics()
            .setDepth(0);

        visualPath
            .lineStyle(44, 0x8a6d46, 1)
            .beginPath()
            .moveTo(
                waypoints[0].x,
                waypoints[0].y
            );

        waypoints.slice(1).forEach(point => {

            visualPath.lineTo(
                point.x,
                point.y
            );

        });

        visualPath.strokePath();


        // =========================
        // DEBUG DOS WAYPOINTS
        // =========================

        waypoints.forEach((point, index) => {

            this.add.circle(
                point.x,
                point.y,
                8,
                0x00ff00
            );

            this.add.text(
                point.x,
                point.y - 25,
                `P${index}`,
                {
                    fontSize: '16px',
                    color: '#ffffff'
                }
            ).setOrigin(0.5);

        });

        // =========================
        // VIDAS
        // =========================

        this.lifeSystem = new LifeSystem(
            this,
            20
        );

        this.livesDisplay = new LivesDisplay(
            this,
            20,
            20,
            this.lifeSystem.lives
        );

        // =========================
        // Dinheiro
        // =========================

        this.moneySystem = new MoneySystem(
            this,
            100,
            1
        );

        this.money = this.moneySystem.money;

        // =========================
        // WAVES
        // =========================

        this.waveManager = new WaveManager(
            this,
            this.path,
            waves
        );

        // =========================
        // SLOTS
        // =========================

        this.slotManager = new SlotManager(
            this,
            slots
        );

        // =========================
        // TORRES
        // =========================

        this.towerManager = new TowerManager(
            this,
            this.waveManager.spawner.enemies
        );

        // =========================
        // INICIAR JOGO
        // =========================

        this.waveManager.start();
    }


    update(time, delta) {

        this.waveManager.update(delta);

        this.towerManager.update(delta);
    }
}