import Tower from '../entities/Tower';
import { towerTypes } from '../data/towers';
import MoneyDisplay from '../ui/MoneyDisplay';

export default class TowerManager {

    constructor(scene, enemies) {

        this.scene = scene;

        this.enemies = enemies;

        this.towers = [];
        this.projectiles = [];

        this.buildSlots = [];

        this.money = 100;
        this.refundRate = 0.75;

        this.moneyDisplay = new MoneyDisplay(
            scene,
            20,
            50,
            this.money
        );
    }

    sellTower(tower) {

        const slot = tower.buildSlot;

        const refund = Math.floor(
            tower.cost * this.refundRate
        );

        this.scene.moneySystem.gainMoney(refund);

        this.updateMoneyDisplay();

        tower.destroy();

        this.towers = this.towers.filter(
            currentTower => currentTower !== tower
        );

        slot.setVisible(true);
        slot.setInteractive();
    }

    updateMoneyDisplay() {

        this.moneyDisplay.update(
            this.money
        );
    }

    update(delta) {

        this.towers.forEach(tower => {
            tower.update(delta);
        });

        this.projectiles.forEach(projectile => {
            projectile.update(delta);
        });

        this.projectiles = this.projectiles.filter(
            projectile => projectile.active
        );
    }
}