import * as Phaser from 'phaser';
import Projectile from './Projectile';

export default class Tower extends Phaser.GameObjects.Rectangle {

    constructor(scene, x, y, data, towerManager) {

        super(
            scene,
            x,
            y,
            data.size,
            data.size,
            data.color
        );

        this.scene = scene;

        this.towerManager = towerManager;

        this.enemies = towerManager.enemies;

        this.cost = data.cost;

        this.range = data.range;
        this.damage = data.damage;
        this.attackCooldown = data.attackCooldown;

        this.target = null;

        scene.add.existing(this);

        this.rangeCircle = scene.add.circle(
            x,
            y,
            this.range,
            0x00ff00,
            0.15
        );

        this.attackEvent = scene.time.addEvent({

            delay: this.attackCooldown,

            loop: true,

            callback: () => {
                this.attack();
            }

        });
    }

    update() {

        this.target = null;

        this.enemies.forEach(enemy => {

            if (!enemy.active) {
                return;
            }

            const distanceToTower = Phaser.Math.Distance.Between(
                this.x,
                this.y,
                enemy.x,
                enemy.y
            );

            if (distanceToTower <= this.range) {

                if (
                    this.target === null ||
                    enemy.pathDistance > this.target.pathDistance
                ) {

                    this.target = enemy;
                }
            }
        });
    }

    attack() {

        if (!this.active) return;

        if (!this.target || !this.target.active) return;

        const projectile = new Projectile(
            this.scene,
            this.x,
            this.y,
            this.target,
            this.damage,
            400
        );

        this.towerManager.projectiles.push(projectile);
    }

    destroy() {

        if (this.attackEvent) {
            this.attackEvent.remove();
        }

        if (this.rangeCircle) {
            this.rangeCircle.destroy();
        }

        super.destroy();
    }
}