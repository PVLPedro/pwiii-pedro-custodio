import * as Phaser from 'phaser';

export default class Tower extends Phaser.GameObjects.Rectangle {

    constructor(scene, x, y, initialCost) {

        super(
            scene,
            x,
            y,
            50,
            50,
            0x00ff00,
            0.5
        );

        this.scene = scene;
        this.initialCost = initialCost;

        scene.add.existing(this);
    }

    destroy() {

        super.destroy();
    }
}