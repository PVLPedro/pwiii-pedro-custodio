import * as Phaser from 'phaser';
import TowerPanel from '../ui/TowerPanel';

export default class HudScene extends Phaser.Scene {
    constructor() {
        super('HudScene');
    }

    create() {
        this.towerPanel = new TowerPanel(this);

        this.input.keyboard.on('keydown-T', () => {
            this.towerPanel.show();
        });

        this.input.keyboard.on('keydown-E', () => {
            this.towerPanel.hide();
        });
    }
}